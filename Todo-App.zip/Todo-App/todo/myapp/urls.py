from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [

 path('',views.Index),
 path('addTodo/', views.addTodo),
 path('deleteTodo',views.deleteTodo),

]