from django.http import HttpResponseRedirect
from django.shortcuts import render,HttpResponse
from .models import TodoItem
# Create your views here.

def Index(request):
    all_todo_items =TodoItem.objects.all()
    return render(request, 'index.html' ,{'all_items':all_todo_items})

    
def addTodo(request):
    
    new_item = TodoItem(content=request.POST['content'])
    new_item.save()

    return HttpResponseRedirect('/todo/') 


def deleteTodo(request,todo_id):
    item_to_delete = TodoItem.objects.get(id=todo_id)
    item_to_delete.delete()
    return HttpResponseRedirect('/todo/') 
